
## Development
```bash
flask --debug run
```