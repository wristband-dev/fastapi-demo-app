import base64
import requests

from src.sdk.models import TokenResponse


class WristbandService:
    def __init__(self, wristband_application_domain: str, client_id: str, client_secret: str) -> None:
        credentials = f"{client_id}:{client_secret}"
        encoded_credentials = base64.b64encode(credentials.encode('utf-8')).decode('utf-8')
        
        self.base_url = f'https://{wristband_application_domain}/api/v1'
        self.headers = { 
            'Authorization': f'Basic {encoded_credentials}',
            'Content-Type': 'application/x-www-form-urlencoded'
        }

    def get_token(self, code: str, redirect_uri: str, code_verifier: str) -> TokenResponse:
        form_data = {
            'grant_type': 'authorization_code',
            'code': code,
            'redirect_uri': redirect_uri,
            'code_verifier': code_verifier,
        }

        response = requests.post(
        'https://api.example.com/endpoint', 
            data=form_data,
            headers=self.headers
        )
        return response.json()


